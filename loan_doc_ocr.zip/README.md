# Automated Personal Loan Document Processing

This project uses OCR to extract data from personal loan documents, validate the data, and display it through a Streamlit interface.

## Setup

```bash
pip install -r requirements.txt
streamlit run main.py
```